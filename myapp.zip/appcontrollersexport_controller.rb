class ExportController < ApplicationController
  def pdf
    @data = MaTable.all
    respond_to do |format|
      format.html
      format.pdf do
        render pdf: "exported_data",
               template: "export/pdf.html.erb"
      end
    end
  end
end