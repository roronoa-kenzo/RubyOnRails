require "test_helper"

class ExportControllerTest < ActionDispatch::IntegrationTest
  test "should get pdf" do
    get export_pdf_url
    assert_response :success
  end
end
