module MaTablesHelper
end
