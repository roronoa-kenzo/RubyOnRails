class MaTable < ApplicationRecord
end
