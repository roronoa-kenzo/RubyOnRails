class ExportController < ApplicationController
  def pdf
  end
end
